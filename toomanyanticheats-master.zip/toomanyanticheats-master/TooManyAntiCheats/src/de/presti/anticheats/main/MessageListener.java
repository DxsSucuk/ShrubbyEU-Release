package de.presti.anticheats.main;

import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.command.PlayerCommand;
import net.md_5.bungee.event.EventHandler;

public class MessageListener implements Listener {

	@EventHandler
	public void onCommandSend(ChatEvent e) {
		ProxiedPlayer p = (ProxiedPlayer) e.getSender();
		if (e.getMessage().toLowerCase().contains("%")) {
			e.setMessage(e.getMessage().replaceAll("%", "prozent"));
		}

		if (e.getMessage().length() > 100) {
			e.setCancelled(true);
			p.sendMessage("�7[�eShrubby.eu�7] �7Mehr als 100 Zeichen!");
		}

		if (e.getMessage().toLowerCase().startsWith("/bauserver")) {
			if (p.hasPermission("system.bauserver")) {
				e.setCancelled(true);
				p.connect(ProxyServer.getInstance().getServerInfo("BauServer-1"));
				p.sendMessage("Connected to the BauServer-1 (you gay shit ;D)");
			} else {
				e.setCancelled(false);
			}
		}

		if (e.getMessage().toLowerCase().startsWith("/bc")) {
			if (p.hasPermission("system.bc") || p.hasPermission("system.*")) {
				
				e.setCancelled(true);

				if (e.getMessage().toLowerCase().replace(" ", "").equalsIgnoreCase("/bc")) {
					p.sendMessage("�7[�eShrubby.eu�7] Bitte benutze /bc [Message]");
				} else {
					String bc = e.getMessage().replace("/bc ", "");
					
					bc = bc.replace("&", "�");

					for (ProxiedPlayer all : ProxyServer.getInstance().getPlayers()) {
						
						all.sendMessage("�a================================================================");
						all.sendMessage("�7");
						all.sendMessage("�7[�eShrubby.eu�7] " + bc);
						all.sendMessage("�7");
						all.sendMessage("�a================================================================");
					}

				}

			}
		}

		if (!p.hasPermission("system.commandbypass")) {
			if (((e.getMessage().toLowerCase().startsWith("/bukkit:")
					|| e.getMessage().toLowerCase().startsWith("/spigot:")
					|| e.getMessage().toLowerCase().startsWith("/minecraft:")
					|| e.getMessage().toLowerCase().startsWith("/say") || e.getMessage().toLowerCase().startsWith("/me")
					|| e.getMessage().toLowerCase().startsWith("/pl") || e.getMessage().toLowerCase().startsWith("/?")))
					&& !e.getMessage().toLowerCase().startsWith("/plot")
					&& !e.getMessage().toLowerCase().startsWith("/plugman")) {
				e.setCancelled(true);
				p.sendMessage("�7[�eShrubby.eu�7] �7Du kannst diesen Command nicht benutzen!");
			} else if (e.getMessage().toLowerCase().startsWith("/aac")) {
				e.setCancelled(true);
				p.sendMessage("�7[�eShrubby.eu�7] �7Ist es NCP oder AAC ich wei� es nicht mehr :D");
			} else if (e.getMessage().toLowerCase().startsWith("/nocheatplus")
					|| e.getMessage().toLowerCase().startsWith("/ncp")) {
				e.setCancelled(true);
				p.sendMessage("<Megatron>: Where is the AntiCheat?");
			} else if (e.getMessage().toLowerCase().startsWith("/spartan")) {
				e.setCancelled(true);
				p.sendMessage("�7<�2Spartana�7>: This is �2SPARTA");
			} else if (e.getMessage().toLowerCase().startsWith("/matrix")) {
				e.setCancelled(true);
				p.sendMessage(
						"�7Die Matrix ist die Welt die �ber deine Augen gest�lpt wurde, damit du blind f�r die Wahrheit bist.");
			} else if (e.getMessage().toLowerCase().startsWith("/pac") || e.getMessage().toLowerCase().startsWith("/prestigeanticheat")) {
				e.setCancelled(true);
				p.sendMessage("�2Prestige�6AntiCheat �7- The Best AntiCheat Solution!");
				p.sendMessage("�2Prestige�6AntiCheat �7- Plugin Version b5 - KI Version b26");
				p.sendMessage("�2Prestige�6AntiCheat �7- �bDeveloped by Prestigemaster62");
				p.sendMessage("�2Prestige�6AntiCheat �7- Licensed to �eShrubby.eu");
			} else if (e.getMessage().toLowerCase().startsWith("/aegis")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEcord �8- �7The Bungeecord Fork with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/flamecord")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEcord �8- �7The Bungeecord Fork with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/skillcord")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEcord �8- �7The Bungeecord Fork with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/reeeeeeeeeeecord")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEcord �8- �7The Bungeecord Fork with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/firewall")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEcord �8- �7The Bungeecord Fork with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/bungee")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEcord �8- �7The Bungeecord Fork with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/spigotguard")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEguard �8- �7The Spigot Protector with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/exploitfixer")) {
				e.setCancelled(true);
				p.sendMessage("�cREEEEEEEEEEEfixer �8- �7The Spigot Fixer with �cREEEEEEEEEEEEEEEEE");
			} else if (e.getMessage().toLowerCase().startsWith("/help")) {
				e.setCancelled(true);
				p.sendMessage("�7[�eShrubby�7] Hey falls du hilfe brauchst meld dich auf Discord! :D");
			} else if (e.getMessage().toLowerCase().startsWith("/timocloud")) {
				e.setCancelled(true);
				p.sendMessage("�7CloudNET ist besser!");
			} else if (e.getMessage().toLowerCase().startsWith("/cloud")) {
				e.setCancelled(true);
				p.sendMessage("�7TimoCloud ist besser!");
			} else if (e.getMessage().toLowerCase().startsWith("/prestigecloud")) {
				e.setCancelled(true);
				p.sendMessage("�cNo Permission for this Command!");
			} else if (e.getMessage().toLowerCase().startsWith("/reecloud")) {
				e.setCancelled(true);
				p.sendMessage("�cNo Permission for this Command!");
			} else if (e.getMessage().toUpperCase().startsWith("/REEEEEYE")) {
				if (p.hasPermission("presti.ree")) {
					e.setCancelled(true);
					p.connect(ProxyServer.getInstance().getServerInfo("Privat-1"));
					p.sendMessage("�7Kinda �cREEEEEEEEEEEEEEEEEEEEEEEEE �7to me");
				} else {
					e.setCancelled(false);
				}
			}
		}
	}

}
