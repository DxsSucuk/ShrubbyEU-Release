package de.presti.anticheats.main;

import java.util.concurrent.TimeUnit;

import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Plugin;

public class AntiCheats extends Plugin {

	int reeeee = 0;
	
	public void onEnable() {
		ProxyServer.getInstance().getPluginManager().registerListener(this, new MessageListener());

		ProxyServer.getInstance().getScheduler().schedule(this, new Runnable() {

			@Override
			public void run() {
				for (ProxiedPlayer all : ProxyServer.getInstance().getPlayers()) {
					sendMessages(all);
				}
				reeeee++;
			}
		}, 0L, 20, TimeUnit.MINUTES);

	}
	
	public void sendMessages(ProxiedPlayer all) {
		if(reeeee == 0) {
			all.sendMessage("�a================================================================");
			all.sendMessage("�7");
			
			all.sendMessage("  Hey du fallst du es nicht wusstest wir haben einen Discord Server!");
			
			TextComponent tc = new TextComponent("                        https://discord.gg/shrubby");
			
			tc.setClickEvent(new ClickEvent(Action.OPEN_URL, "https://discord.gg/shrubby"));
			
			all.sendMessage(tc);
			
			all.sendMessage("�7");
			all.sendMessage("�a================================================================");
		} else if(reeeee == 1) {
			all.sendMessage("�a================================================================");
			all.sendMessage("�7");
			
			all.sendMessage("  Zum Beta Release von Shrubby.eu gibt es einen 50% Sale im Shop!!");
			
			TextComponent tc = new TextComponent("                        https://shop.shrubby.eu");
			
			tc.setClickEvent(new ClickEvent(Action.OPEN_URL, "https://shop.shrubby.eu"));
			
			all.sendMessage(tc);
			
			all.sendMessage("�7");
			all.sendMessage("�a================================================================");
		} else if(reeeee == 2) {
			all.sendMessage("�a================================================================");
			all.sendMessage("�7");
			
			all.sendMessage("  Hacker Gefunden? Melde ihn mit /report!");
			
			TextComponent tc = new TextComponent("       Falls du beweise hast kannst du sie gerne im Forum posten!");
			
			tc.setClickEvent(new ClickEvent(Action.OPEN_URL, "https://shrubby.eu/forum"));
			
			all.sendMessage(tc);
			
			all.sendMessage("�7");
			all.sendMessage("�a================================================================");
		} else if(reeeee == 3) {
			all.sendMessage("�a================================================================");
			all.sendMessage("�7");
			
			all.sendMessage("  Du willst die Sats von Usern sehen? Online? Well eZ geh einfach auf!");
			
			TextComponent tc = new TextComponent("                        https://shrubby.eu/playerinfo");
			
			tc.setClickEvent(new ClickEvent(Action.OPEN_URL, "https://shrubby.eu/playerinfo"));
			
			all.sendMessage(tc);
			
			all.sendMessage("�7");
			all.sendMessage("�a================================================================");
		}
		
		if(reeeee > 3) {
			reeeee = 0;
		}
	}

}
