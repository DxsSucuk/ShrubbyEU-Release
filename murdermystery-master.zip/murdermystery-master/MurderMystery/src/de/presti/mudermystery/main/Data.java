package de.presti.mudermystery.main;

public class Data {
	
	public static String prefix = "�7[�cMurderMystery�7] �e";

}
