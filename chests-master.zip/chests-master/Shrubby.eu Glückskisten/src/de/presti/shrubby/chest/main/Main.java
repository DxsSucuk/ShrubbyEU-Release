package de.presti.shrubby.chest.main;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import de.presti.coinapi.CoinAPI;
import de.presti.shrubby.chest.events.Events;
import de.presti.shrubby.chest.mysql.Locations;
import de.presti.shrubby.chest.mysql.MySQL;
import de.presti.shrubby.chest.util.ChestUtil;

public class Main extends JavaPlugin {

	public static Main instance;
	public MySQL sql;
	public CoinAPI coins;
	public Locations location;
	
	public void onEnable() {
		instance = this;
		sql = new MySQL("chest", "15KiEVM3y7OvYdAl", "localhost", "chest", 3306);
		coins = new CoinAPI("coins", "YqISsNqjQuRcpTny", "localhost", "coins");
		
		location = new Locations();
		
		ChestUtil.loadEverything();
		
		Bukkit.getPluginManager().registerEvents(new Events(), this);
		
	}
	
	public void onDisable() {
		sql.close();
		coins.sql.close();
	}
}
