package de.presti.shrubby.chest.mysql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import de.presti.shrubby.chest.main.Main;

public class Locations {
	public HashMap<String, Location> locs = new HashMap<>();
	
	public Locations()
	{
		Main.instance.location = this;
	}
	
	public void setLocation(String path, Player player) {
		if(locexists(path)) {
			Main.instance.sql.update("DELETE FROM Warps WHERE LOCATION= '" + path + "'");
			Main.instance.sql.update("INSERT INTO Warps (LOCATION, WORLD, X, Y, Z, Yaw, Pitch) VALUES ('" + path + "', '" + player.getLocation().getWorld().getName() + "','" + player.getLocation().getX() + "', '" + player.getLocation().getY() +"', '" + player.getLocation().getZ() +"', '"+ player.getLocation().getYaw() +"', '"+ player.getLocation().getPitch() +"');");
		} else {
			Main.instance.sql.update("INSERT INTO Warps (LOCATION, WORLD, X, Y, Z, Yaw, Pitch) VALUES ('" + path + "', '" + player.getLocation().getWorld().getName() + "','" + player.getLocation().getX() + "', '" + player.getLocation().getY() +"', '" + player.getLocation().getZ() +"', '"+ player.getLocation().getYaw() +"', '"+ player.getLocation().getPitch() +"');");
		}
	}
	public void setLocation(String path, Location loc) {
		if(locexists(path)) {
			Main.instance.sql.update("DELETE FROM Warps WHERE LOCATION= '" + path + "'");
			Main.instance.sql.update("INSERT INTO Warps (LOCATION, WORLD, X, Y, Z, Yaw, Pitch) VALUES ('" + path + "', '" + loc.getWorld().getName() + "','" + loc.getX() + "', '" + loc.getY() +"', '" + loc.getZ() +"', '"+ loc.getYaw() +"', '"+ loc.getPitch() +"');");
		} else {
			Main.instance.sql.update("INSERT INTO Warps (LOCATION, WORLD, X, Y, Z, Yaw, Pitch) VALUES ('" + path + "', '" + loc.getWorld().getName() + "','" + loc.getX() + "', '" + loc.getY() +"', '" + loc.getZ() +"', '"+ loc.getYaw() +"', '"+ loc.getPitch() +"');");
		}
	}
	
	public boolean locexists(String loc) {
		try {
			java.sql.PreparedStatement st = null;
			ResultSet rs = null;
			try {
				st = Main.instance.sql.con.prepareStatement("SELECT * FROM Warps WHERE LOCATION='" + loc + "'");
				rs = st.executeQuery("SELECT * FROM Warps WHERE LOCATION='" + loc + "'");
			} catch (SQLException e) {
			}
			if(rs.next()) {
				return rs.getString("X") != null;
			}
			
			return false;
		} catch (SQLException e) {
			
		}
		return false;
	}
	
	public Location loadloc(String path) {
		 String[] i = new String[6];
			java.sql.PreparedStatement st = null;
			ResultSet rs = null;
			try {
				st = Main.instance.sql.con.prepareStatement("SELECT * FROM Warps WHERE LOCATION='" + path + "'");
				rs = st.executeQuery("SELECT * FROM Warps WHERE LOCATION='" + path + "'");
			} catch (SQLException e) {
			}
				try {
					while(rs.next()) {
					i[5] =  rs.getString("WORLD");
					i[0] = rs.getString("X");
					i[1] =  rs.getString("Y");
					i[2] = rs.getString("Z");
					i[3] =  rs.getString("Yaw");
					i[4] = rs.getString("Pitch");
					}
				} catch (NumberFormatException e) {
					i[0] = "0";
					i[1] = "100";
					i[2] = "0";
					i[3] = "0";
					i[4] = "0";
					i[5] = "world";
				} catch (SQLException e) {
					i[0] = "0";
					i[1] = "100";
					i[2] = "0";
					i[3] = "0";
					i[4] = "0";
					i[5] = "world";

				}		
				Location newloc = new Location(Bukkit.getWorld(i[5]), Double.parseDouble(i[0]),
						Double.parseDouble(i[1]), Double.parseDouble(i[2]));
				return newloc;
	}
	
	public Location getLocation(String path) {
			if(!locs.containsKey(path)) {
				locs.put(path, loadloc(path));
			}
			return locs.get(path);
	}
}
