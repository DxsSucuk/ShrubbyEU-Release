package de.presti.shrubby.chest.util;

import java.awt.Event;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.xml.crypto.Data;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

import de.presti.shrubby.chest.events.Events;
import de.presti.shrubby.chest.main.Main;
import de.presti.shrubby.chest.mysql.ChestSQL;

public class InvManager {

	public static String InventoryName = "�eSchatztruhen";

	static Inventory maininv = Bukkit.createInventory(null, (3 * 9), InventoryName);

	public static HashMap<Player, BukkitRunnable> runnable = new HashMap<>();
	public static ArrayList<Player> uses = new ArrayList<Player>();

	public static void openMainInventory(Player p) {

		maininv = Bukkit.createInventory(p, (3 * 9), InventoryName);

		maininv.clear();

		maininv.setItem(12, getNormalChest(ChestSQL.getDailyChest(p.getUniqueId().toString())));
		maininv.setItem(13, getCommunityChest(ChestSQL.getCommunity(p.getUniqueId().toString())));
		maininv.setItem(14, getLegendChest(ChestSQL.getLegend(p.getUniqueId().toString())));

		p.openInventory(maininv);
	}

	public static ItemStack getNormalChest(Integer zahl) {
		ItemStack item = new ItemStack(Material.CHEST);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName("�6Daily �aSchatztruhe");
		ArrayList<String> lore = new ArrayList<String>();
		lore.add("�7Du hast " + zahl + " Truhen");
		meta.setLore(lore);
		item.setItemMeta(meta);
		lore.clear();
		return item;
	}

	public static ItemStack getCommunityChest(Integer zahl) {
		ItemStack item = new ItemStack(Material.TRAPPED_CHEST);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName("�5Community �aSchatztruhe");
		ArrayList<String> lore = new ArrayList<String>();
		lore.add("�7Du hast " + zahl + " Truhen");
		meta.setLore(lore);
		item.setItemMeta(meta);
		lore.clear();
		return item;
	}

	public static ItemStack getLegendChest(Integer zahl) {
		ItemStack item = new ItemStack(Material.ENDER_CHEST);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName("�cLegend �aSchatztruhe");
		ArrayList<String> lore = new ArrayList<String>();
		lore.add("�7Du hast " + zahl + " Truhen");
		meta.setLore(lore);
		item.setItemMeta(meta);
		lore.clear();
		return item;
	}

	public static ItemStack getBlankedGlass() {
		ItemStack item = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short) 15);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName("�7");
		item.setItemMeta(meta);
		return item;
	}

	public static ItemStack getHopper() {
		ItemStack item = new ItemStack(Material.HOPPER);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName("�eDein Gewinn!");
		item.setItemMeta(meta);
		return item;
	}

	public static Inventory chestTemplate(Player p) {
		Inventory inv = Bukkit.createInventory(p, 9 * 3, "�eViel Gl�ck!");

		for (int i = 0; i < 27; i++) {
			if ((i < 9) || (i > 17)) {
				inv.setItem(i, getBlankedGlass());
			}
		}

		inv.setItem(4, getHopper());

		return inv;
	}

	// 9 17

	public static void openDailyChest(Player p) {

		if (ChestUtil.use) {
			p.sendMessage(Events.prefix + "Du kannst die Kiste gerade nicht benutzen!");
		} else {

			ChestUtil.use = true;

			uses.add(p);

			ChestSQL.addDaily(p.getUniqueId().toString(), -1);

			p.getOpenInventory().close();

			p.openInventory(chestTemplate(p));

			runnable.put(p, new BukkitRunnable() {

				int animation = 15;
				Inventory inv = p.getOpenInventory().getTopInventory();
				String username = p.getName();
				ItemStack win = ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size()));
				Player user = p;

				@Override
				public void run() {

					try {
						if (animation == 15) {
							inv.setItem(9, ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(10,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(11,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(12,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(13,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(14,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(15,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(16,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							inv.setItem(17,
									ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
						}

						if (animation <= 0) {
							user.sendMessage(Events.prefix + "Gewinn: " + win.getItemMeta().getDisplayName());
							if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�e1.000 Shrubs")) {
								Main.instance.coins.addCoins(user.getUniqueId().toString(), 1000);
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�75.000 Shrubs")) {
								Main.instance.coins.addCoins(user.getUniqueId().toString(), 5000);
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�b10.000 Shrubs")) {
								Main.instance.coins.addCoins(user.getUniqueId().toString(), 10000);
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�5Community Kiste")) {
								ChestSQL.addComm(user.getUniqueId().toString(), 1);
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�b5 Diamonds")) {
								p.getInventory().addItem(new ItemStack(Material.DIAMOND, 5));
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�7Huhn Spawnei")) {
								p.getInventory().addItem(new ItemStack(Material.MONSTER_EGG, 1, (short) 93));
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�cFarbige Chat Message")) {
								Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
										"lp user " + p.getName() + " permission set system.setcolor");
								Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp networksync");
							}

							uses.remove(p);

							ChestUtil.use = false;

							runnable.get(p).cancel();
						} else {
							if (animation != 5) {
								inv.setItem(9, inv.getItem(10));
								inv.setItem(10, inv.getItem(11));
								inv.setItem(11, inv.getItem(12));
								inv.setItem(12, inv.getItem(13));
								inv.setItem(13, inv.getItem(14));
								inv.setItem(14, inv.getItem(15));
								inv.setItem(15, inv.getItem(16));
								inv.setItem(16, inv.getItem(17));
								inv.setItem(17,
										ChestUtil.dailyitems.get(new Random().nextInt(ChestUtil.dailyitems.size())));
							} else {
								inv.setItem(9, inv.getItem(10));
								inv.setItem(10, inv.getItem(11));
								inv.setItem(11, inv.getItem(12));
								inv.setItem(12, inv.getItem(13));
								inv.setItem(13, inv.getItem(14));
								inv.setItem(14, inv.getItem(15));
								inv.setItem(15, inv.getItem(16));
								inv.setItem(16, inv.getItem(17));
								inv.setItem(17, win);
							}
							animation--;
						}
					} catch (Exception ex) {
					}
				}
			});

			runnable.get(p).runTaskTimer(Main.instance, 0L, 20L);
		}

	}

	public static void openCommunityChest(Player p) {

		if (ChestUtil.use) {
			p.sendMessage(Events.prefix + "Du kannst die Kiste gerade nicht benutzen!");
		} else {

			ChestUtil.use = true;

			uses.add(p);

			ChestSQL.addComm(p.getUniqueId().toString(), -1);

			p.getOpenInventory().close();

			p.openInventory(chestTemplate(p));

			runnable.put(p, new BukkitRunnable() {

				int animation = 15;
				Inventory inv = p.getOpenInventory().getTopInventory();
				String username = p.getName();
				ItemStack win = ChestUtil.communityitems.get(new Random().nextInt(ChestUtil.communityitems.size()));

				@Override
				public void run() {

					try {

						if (animation == 15) {
							inv.setItem(9, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(10, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(11, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(12, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(13, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(14, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(15, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(16, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
							inv.setItem(17, ChestUtil.communityitems
									.get(new Random().nextInt(ChestUtil.communityitems.size())));
						}

						if (animation <= 0) {
							p.sendMessage(Events.prefix + "Gewinn: " + win.getItemMeta().getDisplayName());
							if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�75.000 Shrubs")) {
								for (Player all : Bukkit.getOnlinePlayers()) {
									all.sendMessage(Events.prefix + "Du hast durch den Spieler �c" + p.getName()
											+ " �75.000 Shrubs bekommen!");
									Main.instance.coins.addCoins(all.getUniqueId().toString(), 5000);
								}
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�b10.000 Shrubs")) {
								for (Player all : Bukkit.getOnlinePlayers()) {
									all.sendMessage(Events.prefix + "Du hast durch den Spieler �c" + p.getName()
											+ " �710.000 Shrubs bekommen!");
									Main.instance.coins.addCoins(all.getUniqueId().toString(), 10000);
								}
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�b5 Diamonds")) {
								for (Player all : Bukkit.getOnlinePlayers()) {
									all.sendMessage(Events.prefix + "Du hast durch den Spieler �c" + p.getName()
											+ " �75 Diamonds bekommen!");
									all.getInventory().addItem(new ItemStack(Material.DIAMOND, 5));
								}
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�c30 Min Fly")) {

								for (Player all : Bukkit.getOnlinePlayers()) {
									if (all.getWorld().getName().toLowerCase().startsWith("plot")) {
										all.setAllowFlight(true);
									}

									all.sendMessage(Events.prefix + "Durch den Spieler �c" + p.getName()
											+ " �7k�nnen nun alle Spieler f�r 30 min fliegen!");
								}

								Bukkit.getScheduler().scheduleSyncDelayedTask(Main.instance, new Runnable() {

									@Override
									public void run() {
										for (Player all : Bukkit.getOnlinePlayers()) {
											if (all.getWorld().getName().toLowerCase().startsWith("plot")) {
												all.setAllowFlight(false);
											}
										}
									}
								}, 600L);
							} else if (win.getItemMeta().getDisplayName().equalsIgnoreCase("�eGoldapfel")) {
								for (Player all : Bukkit.getOnlinePlayers()) {
									all.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE));
									all.sendMessage(Events.prefix + "Du hast durch den Spieler �c" + p.getName()
									+ " �7einen Goldapfel bekommen!");
								}
							}

							uses.remove(p);

							ChestUtil.use = false;

							runnable.get(p).cancel();
						} else {
							if (animation != 5) {
								inv.setItem(9, inv.getItem(10));
								inv.setItem(10, inv.getItem(11));
								inv.setItem(11, inv.getItem(12));
								inv.setItem(12, inv.getItem(13));
								inv.setItem(13, inv.getItem(14));
								inv.setItem(14, inv.getItem(15));
								inv.setItem(15, inv.getItem(16));
								inv.setItem(16, inv.getItem(17));
								inv.setItem(17, ChestUtil.communityitems
										.get(new Random().nextInt(ChestUtil.communityitems.size())));
							} else {
								inv.setItem(9, inv.getItem(10));
								inv.setItem(10, inv.getItem(11));
								inv.setItem(11, inv.getItem(12));
								inv.setItem(12, inv.getItem(13));
								inv.setItem(13, inv.getItem(14));
								inv.setItem(14, inv.getItem(15));
								inv.setItem(15, inv.getItem(16));
								inv.setItem(16, inv.getItem(17));
								inv.setItem(17, win);
							}
							animation--;
						}
					} catch (Exception ex) {

					}
				}
			});

			runnable.get(p).runTaskTimer(Main.instance, 0L, 20L);
		}

	}

	public static void openLegendChest(Player p) {

		if (ChestUtil.use) {
			p.sendMessage(Events.prefix + "Du kannst die Kiste gerade nicht benutzen!");
		} else {

			ChestUtil.use = true;

			uses.add(p);

			ChestSQL.addLegend(p.getUniqueId().toString(), -1);

			p.getOpenInventory().close();

			p.openInventory(chestTemplate(p));

			runnable.put(p, new BukkitRunnable() {

				int animation = 15;
				Inventory inv = p.getOpenInventory().getTopInventory();
				String username = p.getName();
				ItemStack win = ChestUtil.legenditems.get(new Random().nextInt(ChestUtil.legenditems.size()));

				@Override
				public void run() {

					try {

						if (animation == 15) {
							inv.setItem(9, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(10, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(11, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(12, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(13, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(14, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(15, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(16, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
							inv.setItem(17, ChestUtil.legenditems
									.get(new Random().nextInt(ChestUtil.legenditems.size())));
						}

						if (animation <= 0) {
							p.sendMessage(Events.prefix + "Gewinn: " + win.getItemMeta().getDisplayName());
							
							if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�bBeacon")) {
								p.getInventory().addItem(new ItemStack(Material.BEACON));
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�cAliphant_18")) {
								ItemStack secon = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
								SkullMeta m2 = (SkullMeta) secon.getItemMeta();

								m2.setOwner("Aliphant_18");

								m2.setDisplayName("�cAliphant_18");

								secon.setItemMeta(m2);
								p.getInventory().addItem(secon);
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�cYeahIMissYou")) {
								ItemStack three = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
								SkullMeta m3 = (SkullMeta) three.getItemMeta();

								m3.setOwner("YeahIMissYou");
								m3.setDisplayName("�cYeahIMissYou");

								three.setItemMeta(m3);
								p.getInventory().addItem(three);
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�bPrestigemaster62")) {
								ItemStack four = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
								SkullMeta m4 = (SkullMeta) four.getItemMeta();

								m4.setOwner("Prestigemaster62");
								m4.setDisplayName("�bPrestigemaster62");

								four.setItemMeta(m4);

								p.getInventory().addItem(four);
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�6Champion Lifetime")) {
								if(p.hasPermission("system.champ")) {
									p.sendMessage(Events.prefix + "Da du den Champion Rang oder einen h�heren Rang hast kriegst du 10k Shrubs!");
									Main.instance.coins.addCoins(p.getUniqueId().toString(), 10000);
								} else {
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + p.getName() + " parent set champ");
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp networksync");
								}
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�bMaster Lifetime")) {
								if(p.hasPermission("system.master")) {
									p.sendMessage(Events.prefix + "Da du den Master Rang oder einen h�heren Rang hast kriegst du 10k Shrubs!");
									Main.instance.coins.addCoins(p.getUniqueId().toString(), 10000);
								} else {
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + p.getName() + " parent set master");
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp networksync");
								}
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�c50k Shrubs")) {
								Main.instance.coins.addCoins(p.getUniqueId().toString(), 50000);
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�cM�rder Klinge")) {
								p.getInventory().addItem(win);
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�c3 �5CommunityKisten")) {
								ChestSQL.addComm(p.getUniqueId().toString(), 3);
							} else if(win.getItemMeta().getDisplayName().equalsIgnoreCase("�6100k Shrubs")) {
								Main.instance.coins.addCoins(p.getUniqueId().toString(), 100000);
							}
							
							uses.remove(p);

							ChestUtil.use = false;

							runnable.get(p).cancel();
						} else {
							if (animation != 5) {
								inv.setItem(9, inv.getItem(10));
								inv.setItem(10, inv.getItem(11));
								inv.setItem(11, inv.getItem(12));
								inv.setItem(12, inv.getItem(13));
								inv.setItem(13, inv.getItem(14));
								inv.setItem(14, inv.getItem(15));
								inv.setItem(15, inv.getItem(16));
								inv.setItem(16, inv.getItem(17));
								inv.setItem(17, ChestUtil.legenditems
										.get(new Random().nextInt(ChestUtil.legenditems.size())));
							} else {
								inv.setItem(9, inv.getItem(10));
								inv.setItem(10, inv.getItem(11));
								inv.setItem(11, inv.getItem(12));
								inv.setItem(12, inv.getItem(13));
								inv.setItem(13, inv.getItem(14));
								inv.setItem(14, inv.getItem(15));
								inv.setItem(15, inv.getItem(16));
								inv.setItem(16, inv.getItem(17));
								inv.setItem(17, win);
							}
							animation--;
						}
					} catch (Exception ex) {

					}
				}
			});

			runnable.get(p).runTaskTimer(Main.instance, 0L, 20L);
		}

	}

}
