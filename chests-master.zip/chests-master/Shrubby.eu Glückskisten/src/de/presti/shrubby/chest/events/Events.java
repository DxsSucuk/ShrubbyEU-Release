package de.presti.shrubby.chest.events;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event.Result;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import de.presti.shrubby.chest.main.Main;
import de.presti.shrubby.chest.util.ChestUtil;
import de.presti.shrubby.chest.util.InvManager;

public class Events implements Listener {

	public static String prefix = "�7[�eShrubby.eu�7] �7";

	@EventHandler
	public void onBlockInteract(PlayerInteractEvent e) {
		if (e.getAction() != Action.RIGHT_CLICK_BLOCK) {
			return;
		}

		if (!(e.getPlayer() instanceof Player)) {
			return;
		}

		if (e.getClickedBlock() == null) {
			return;
		}

		Player p = (Player) e.getPlayer();

		if (e.getClickedBlock().getType().equals(Material.CHEST) && e.getClickedBlock().getLocation().equals(Main.instance.location.loadloc("chest"))) {
			e.setCancelled(true);
			InvManager.openMainInventory(p);
		}

	}

	@EventHandler
	public void InvClicked(InventoryClickEvent e) {
		if (e.getCurrentItem() == null) {
			return;
		}

		if (e.getClickedInventory() == null) {
			return;
		}

		if (e.getView().getPlayer() instanceof Player) {

			Player p = (Player) e.getView().getPlayer();

			if (e.getInventory().getTitle().equalsIgnoreCase(InvManager.InventoryName)) {
				
				e.setCancelled(true);
				e.getResult();
				e.setResult(Result.DENY);
				
				if (e.getCurrentItem().getType().equals(Material.CHEST)) {
					if (ChestUtil.hasDailyChest(p.getUniqueId().toString())) {
						if (!ChestUtil.use) {
							InvManager.openDailyChest(p);
						} else {
							p.sendMessage(prefix + "Die Kiste wird schon benutzt!");
						}
					} else {
						p.sendMessage(prefix + "Du hast keine DailyChests!");
					}
				} else if (e.getCurrentItem().getType().equals(Material.TRAPPED_CHEST)) {
					if (ChestUtil.hasCommunityChest(p.getUniqueId().toString())) {
						if (!ChestUtil.use) {
							InvManager.openCommunityChest(p);
						} else {
							p.sendMessage(prefix + "Die Kiste wird schon benutzt!");
						}
					} else {
						p.sendMessage(prefix + "Du hast keine CommunityChests!");
					}
				} else if (e.getCurrentItem().getType().equals(Material.ENDER_CHEST)) {
					if (ChestUtil.hasLegendChest(p.getUniqueId().toString())) {
						if (!ChestUtil.use) {
							InvManager.openLegendChest(p);
						} else {
							p.sendMessage(prefix + "Die Kiste wird schon benutzt!");
						}
					} else {
						p.sendMessage(prefix + "Du hast keine LegendChests!");
					}
				}
			} else if (e.getInventory().getTitle().equalsIgnoreCase("�eViel Gl�ck!")) {
				e.setCancelled(true);
				e.getResult();
				e.setResult(Result.DENY);
			}
		}
	}

}
