package de.presti.shrubby.chest.mysql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import de.presti.shrubby.chest.main.Main;


public class ChestSQL {
	
	public static boolean playerexists(String uuid) {
		try {
			java.sql.PreparedStatement st = null;
			ResultSet rs = null;
			try {
				st = Main.instance.sql.con.prepareStatement("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
				rs = st.executeQuery("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
			} catch (SQLException e) {
			}
			if(rs.next()) {
				return rs.getString("PLAYER") != null;
			}
			
			return false;
		} catch (SQLException e) {
			
		}
		return false;
	}
	
	public static void addplayer(String uuid) {
		if(!playerexists(uuid)) {
			Main.instance.sql.update("INSERT INTO CHEST (PLAYER , DAILY, COMM, LEGEND) VALUES ('" + uuid + "', '0', '0', '0');");			
		}
	}
	
	
	public static Integer getDailyChest(String uuid) {
		Integer i = Integer.valueOf(0);
		if(playerexists(uuid)) {
			java.sql.PreparedStatement st = null;
			ResultSet rs = null;
			try {
				st = Main.instance.sql.con.prepareStatement("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
				rs = st.executeQuery("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
			} catch (SQLException e) {
			}
			try {
				while(rs.next()) {
					i = Integer.valueOf(rs.getString("DAILY"));
				}
			} catch(Exception e) {
				
			}
		} else {
			addplayer(uuid);
			getDailyChest(uuid);
		}
		return i;
	}
	
	public static Integer getLegend(String uuid) {
		Integer i = Integer.valueOf(0);
		if(playerexists(uuid)) {
			java.sql.PreparedStatement st = null;
			ResultSet rs = null;
			try {
				st = Main.instance.sql.con.prepareStatement("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
				rs = st.executeQuery("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
			} catch (SQLException e) {
			}
			try {
				while(rs.next()) {
					i = Integer.valueOf(rs.getString("LEGEND"));
				}
			} catch(Exception e) {
				
			}
		} else {
			addplayer(uuid);
			getLegend(uuid);
		}
		return i;
	}
	
	public static Integer getCommunity(String uuid) {
		Integer i = Integer.valueOf(0);
		if(playerexists(uuid)) {
			java.sql.PreparedStatement st = null;
			ResultSet rs = null;
			try {
				st = Main.instance.sql.con.prepareStatement("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
				rs = st.executeQuery("SELECT * FROM CHEST WHERE PLAYER='" + uuid + "'");
			} catch (SQLException e) {
			}
			try {
				while(rs.next()) {
					i = Integer.valueOf(rs.getString("COMM"));
				}
			} catch(Exception e) {
				
			}
		} else {
			addplayer(uuid);
			getLegend(uuid);
		}
		return i;
	}
	
	public static void addDaily(String uuid, int MM) {
		setDailyChest(uuid, getDailyChest(uuid) + MM);
	}
	
	public static void addLegend(String uuid, int MM) {
		setLegend(uuid, getLegend(uuid) + MM);
	}
	
	public static void addComm(String uuid, int MM) {
		setCommunity(uuid, getCommunity(uuid) + MM);
	}
	
	
	public static void setDailyChest(String uuid, int MM) {
		if(playerexists(uuid)) {
			Main.instance.sql.update("UPDATE CHEST SET DAILY='" + MM + "' WHERE PLAYER='" + uuid + "'");
		} else {
			addplayer(uuid);
			setDailyChest(uuid, MM);
		}
	}
	
	public static void setLegend(String uuid, int MM) {
		if(playerexists(uuid)) {
			Main.instance.sql.update("UPDATE CHEST SET LEGEND='" + MM + "' WHERE PLAYER='" + uuid + "'");
		} else {
			addplayer(uuid);
			setLegend(uuid, MM);
		}
	}
	
	public static void setCommunity(String uuid, int MM) {
		if(playerexists(uuid)) {
			Main.instance.sql.update("UPDATE CHEST SET COMM='" + MM + "' WHERE PLAYER='" + uuid + "'");
		} else {
			addplayer(uuid);
			setCommunity(uuid, MM);
		}
	}
	
}

