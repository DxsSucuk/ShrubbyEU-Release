package de.presti.shrubby.chest.util;

import java.util.ArrayList;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import de.presti.shrubby.chest.mysql.ChestSQL;

public class ChestUtil {

	public static ArrayList<ItemStack> dailyitems = new ArrayList<ItemStack>();
	public static ArrayList<ItemStack> communityitems = new ArrayList<ItemStack>();
	public static ArrayList<ItemStack> legenditems = new ArrayList<ItemStack>();
	public static boolean use = false;

	public static boolean hasDailyChest(String uuid) {
		Integer chest = ChestSQL.getDailyChest(uuid);
		return chest > 0;
	}

	public static boolean hasCommunityChest(String uuid) {
		Integer chest = ChestSQL.getCommunity(uuid);
		return chest > 0;
	}

	public static boolean hasLegendChest(String uuid) {
		Integer chest = ChestSQL.getLegend(uuid);
		return chest > 0;
	}

	public static void loadDailyChestWins() {
		ItemStack first = new ItemStack(Material.GOLD_BLOCK);
		ItemMeta meta = first.getItemMeta();

		meta.setDisplayName("�e1.000 Shrubs");

		first.setItemMeta(meta);

		ItemStack secon = new ItemStack(Material.IRON_BLOCK);
		ItemMeta m2 = secon.getItemMeta();

		m2.setDisplayName("�75.000 Shrubs");

		secon.setItemMeta(m2);

		ItemStack three = new ItemStack(Material.DIAMOND_BLOCK);
		ItemMeta m3 = three.getItemMeta();

		m3.setDisplayName("�b10.000 Shrubs");

		three.setItemMeta(m3);

		ItemStack four = new ItemStack(Material.DIAMOND);
		ItemMeta m4 = four.getItemMeta();
		m4.setDisplayName("�b5 Diamonds");

		four.setItemMeta(m4);

		ItemStack five = new ItemStack(Material.MONSTER_EGG, 1, (short)93);
		ItemMeta m5 = five.getItemMeta();
		m5.setDisplayName("�7Huhn Spawnei");

		five.setItemMeta(m5);

		ItemStack six = new ItemStack(Material.CHEST);
		ItemMeta m6 = six.getItemMeta();
		m6.setDisplayName("�5Community Kiste");
		six.setItemMeta(m6);

		ItemStack seven = new ItemStack(Material.NAME_TAG);
		ItemMeta m7 = seven.getItemMeta();
		m7.setDisplayName("�cFarbige Chat Message");
		seven.setItemMeta(m7);

		for (int i = 0; i < 17; i++) {
			dailyitems.add(five);
		}

		for (int i = 0; i < 10; i++) {
			dailyitems.add(first);
		}

		for (int i = 0; i < 3; i++) {
			dailyitems.add(three);
		}

		for (int i = 0; i < 30; i++) {
			dailyitems.add(four);
		}

		for (int i = 0; i < 6; i++) {
			dailyitems.add(secon);
		}

		for (int i = 0; i < 2; i++) {
			dailyitems.add(seven);
		}

		for (int i = 0; i < 5; i++) {
			dailyitems.add(six);
		}

	}

	public static void loadCommunityChestWins() {

		ItemStack first = new ItemStack(Material.GOLDEN_APPLE);
		ItemMeta meta = first.getItemMeta();

		meta.setDisplayName("�eGoldapfel");

		first.setItemMeta(meta);

		ItemStack secon = new ItemStack(Material.IRON_BLOCK);
		ItemMeta m2 = secon.getItemMeta();

		m2.setDisplayName("�75.000 Shrubs");

		secon.setItemMeta(m2);

		ItemStack three = new ItemStack(Material.DIAMOND_BLOCK);
		ItemMeta m3 = three.getItemMeta();

		m3.setDisplayName("�b10.000 Shrubs");

		three.setItemMeta(m3);

		ItemStack four = new ItemStack(Material.DIAMOND);
		ItemMeta m4 = four.getItemMeta();
		m4.setDisplayName("�b5 Diamonds");

		four.setItemMeta(m4);

		ItemStack five = new ItemStack(Material.FEATHER);
		ItemMeta m5 = five.getItemMeta();
		m5.setDisplayName("�c30 Min Fly");

		five.setItemMeta(m5);

		ItemStack six = new ItemStack(Material.CHEST);
		ItemMeta m6 = six.getItemMeta();
		m6.setDisplayName("�aFree Plot");
		six.setItemMeta(m6);

		for (int i = 0; i < 20; i++) {
			communityitems.add(first);
		}

		for (int i = 0; i < 6; i++) {
			communityitems.add(secon);
		}

		for (int i = 0; i < 3; i++) {
			communityitems.add(three);
		}

		for (int i = 0; i < 30; i++) {
			communityitems.add(four);
		}

		communityitems.add(five);
		communityitems.add(six);
	}

	public static void loadLegendChestWins() {
		ItemStack first = new ItemStack(Material.BEACON);
		ItemMeta meta = first.getItemMeta();

		meta.setDisplayName("�bBeacon");

		first.setItemMeta(meta);

		ItemStack secon = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
		SkullMeta m2 = (SkullMeta) secon.getItemMeta();

		m2.setOwner("Aliphant_18");

		m2.setDisplayName("�cAliphant_18");

		secon.setItemMeta(m2);

		ItemStack three = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
		SkullMeta m3 = (SkullMeta) three.getItemMeta();

		m3.setOwner("YeahIMissYou");
		m3.setDisplayName("�cYeahIMissYou");

		three.setItemMeta(m3);

		ItemStack four = new ItemStack(Material.SKULL_ITEM , 1, (short) 3);
		SkullMeta m4 = (SkullMeta) four.getItemMeta();

		m4.setOwner("Prestigemaster62");
		m4.setDisplayName("�bPrestigemaster62");

		four.setItemMeta(m4);

		ItemStack five = new ItemStack(Material.GOLD_CHESTPLATE);
		ItemMeta m5 = five.getItemMeta();
		m5.setDisplayName("�6Champion Lifetime");

		five.setItemMeta(m5);

		ItemStack six = new ItemStack(Material.IRON_CHESTPLATE);
		ItemMeta m6 = six.getItemMeta();
		m6.setDisplayName("�bMaster Lifetime");
		six.setItemMeta(m6);

		ItemStack seven = new ItemStack(Material.DEAD_BUSH);
		ItemMeta m7 = seven.getItemMeta();
		m7.setDisplayName("�c50k Shrubs");
		seven.setItemMeta(m7);

		ItemStack eight = new ItemStack(Material.IRON_SWORD);
		ItemMeta m8 = eight.getItemMeta();
		m8.setDisplayName("�cM�rder Klinge");
		m8.addEnchant(Enchantment.DAMAGE_ALL, 5, false);
		m8.addEnchant(Enchantment.DURABILITY, 3, false);
		m8.addEnchant(Enchantment.LUCK, 3, false);
		eight.setItemMeta(m8);

		ItemStack nine = new ItemStack(Material.CHEST);
		ItemMeta m9 = nine.getItemMeta();
		m9.setDisplayName("�c3 �5CommunityKisten");
		nine.setItemMeta(m9);

		ItemStack ten = new ItemStack(Material.DIAMOND);
		ItemMeta m10 = ten.getItemMeta();
		m10.setDisplayName("�6100k Shrubs");
		ten.setItemMeta(m10);
		
		for(int i = 0; i < 7; i++) {
			legenditems.add(first);
		}
		
		for(int i = 0; i < 15; i++) {
			legenditems.add(secon);
		}
		
		for(int i = 0; i < 15; i++) {
			legenditems.add(three);
		}
		
		for(int i = 0; i < 15; i++) {
			legenditems.add(four);
		}
		
		legenditems.add(five);
		
		legenditems.add(six);
		
		for(int i = 0; i < 3; i++) {
			legenditems.add(seven);
		}
		
		for(int i = 0; i < 7; i++) {
			legenditems.add(eight);
		}
		
		for(int i = 0; i < 5; i++) {
			legenditems.add(nine);
		}
		
		legenditems.add(ten);
	}

	public static void loadEverything() {
		loadDailyChestWins();
		loadCommunityChestWins();
		loadLegendChestWins();
	}

}
