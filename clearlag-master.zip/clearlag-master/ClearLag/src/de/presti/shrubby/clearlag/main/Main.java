package de.presti.shrubby.clearlag.main;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import net.minecraft.server.v1_8_R3.EntityItem;

public class Main extends JavaPlugin {

	public void onEnable() {
		Bukkit.getScheduler().scheduleSyncRepeatingTask(this, new BukkitRunnable() {

			int timer = 1800;

			@Override
			public void run() {
				if (timer == 0) {
					for (World w : Bukkit.getWorlds()) {
						for (Entity e : w.getEntities()) {
							if (e instanceof EntityItem) {
								if (e.isOnGround()) {
									e.remove();
								}
							}
						}
					}

					Bukkit.broadcastMessage("�a========================================");
					Bukkit.broadcastMessage("�7");
					Bukkit.broadcastMessage(
							"�6[ClearLag] �2Alle Items auf dem Boden wurden gel�scht!");
					Bukkit.broadcastMessage("�7");
					Bukkit.broadcastMessage("�a========================================");

					timer = 1800;

				} else if (timer <= 5) {
					
					Bukkit.broadcastMessage("�a========================================");
					Bukkit.broadcastMessage("�7");
					Bukkit.broadcastMessage(
							"�6[ClearLag] �2Alle Items auf dem Boden werden in " + timer + "s gel�scht!");
					Bukkit.broadcastMessage("�7");
					Bukkit.broadcastMessage("�a========================================");

					
				} else if (timer == 60) {
					Bukkit.broadcastMessage("�a========================================");
					Bukkit.broadcastMessage("�7");
					Bukkit.broadcastMessage(
							"�6[ClearLag] �2Alle Items auf dem Boden werden in " + timer + "s gel�scht!");
					Bukkit.broadcastMessage("�7");
					Bukkit.broadcastMessage("�a========================================");
				}
				if (timer != 0) {
					timer--;
				}
			}
		}, 0L, 20L);
	}

}
